/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9993907587725392, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.98, 500, 1500, "Lead starts assessment"], "isController": false}, {"data": [1.0, 500, 1500, "Create claim"], "isController": false}, {"data": [0.12, 500, 1500, "Concurrent complete claims workflow"], "isController": true}, {"data": [0.9999570465186204, 500, 1500, "Get session and CSRF token"], "isController": false}, {"data": [0.96, 500, 1500, "Record required invoice"], "isController": false}, {"data": [0.98, 500, 1500, "Assessor records report"], "isController": false}, {"data": [1.0, 500, 1500, "Authenticated list claims"], "isController": false}, {"data": [0.97, 500, 1500, "Clerk verifies documents"], "isController": false}, {"data": [0.99, 500, 1500, "Assessor approves"], "isController": false}, {"data": [0.96, 500, 1500, "Finance initiates payment"], "isController": false}, {"data": [0.94, 500, 1500, "Lead assigns assessor"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 93509, 0, 0.0, 28.88085638815506, 0, 778, 10.0, 43.0, 49.0, 65.0, 1558.8470643150067, 6437.664703144275, 528.7848251831678], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Lead starts assessment", 50, 0, 0.0, 267.41999999999996, 97, 754, 242.0, 454.7, 572.6999999999992, 754.0, 4.81139337952271, 4.905365906466513, 3.1950659160892996], "isController": false}, {"data": ["Create claim", 50, 0, 0.0, 62.40000000000001, 6, 188, 46.5, 148.8, 170.89999999999998, 188.0, 5.134524543027315, 3.4748295979667283, 3.1539218140275214], "isController": false}, {"data": ["Concurrent complete claims workflow", 50, 0, 0.0, 1896.58, 851, 3553, 1948.5, 2668.5, 2950.199999999998, 3553.0, 4.325259515570934, 27.104678038494807, 19.983205828287197], "isController": true}, {"data": ["Get session and CSRF token", 46562, 0, 0.0, 23.970791632661648, 0, 620, 7.0, 41.0, 48.0, 63.0, 776.2144500383423, 432.89156792834996, 256.9262906136432], "isController": false}, {"data": ["Record required invoice", 50, 0, 0.0, 254.72, 91, 658, 221.0, 444.09999999999997, 586.2999999999996, 658.0, 4.992012779552716, 3.432008785942492, 3.3832586611421727], "isController": false}, {"data": ["Assessor records report", 50, 0, 0.0, 282.9799999999999, 96, 649, 260.5, 454.7, 529.5999999999996, 649.0, 4.7523999619808, 3.5828640338370876, 3.081634350346925], "isController": false}, {"data": ["Authenticated list claims", 46547, 0, 0.0, 31.936386877779228, 2, 408, 14.0, 48.0, 55.0, 71.9900000000016, 796.5739124482321, 6158.317988162928, 274.6001866154551], "isController": false}, {"data": ["Clerk verifies documents", 50, 0, 0.0, 256.53999999999985, 108, 625, 222.0, 426.0, 530.9, 625.0, 4.975619464623345, 4.961042454473082, 3.3332763210269682], "isController": false}, {"data": ["Assessor approves", 50, 0, 0.0, 254.40000000000003, 107, 513, 237.5, 424.2, 464.4499999999998, 513.0, 4.6935135642542, 4.881437447197972, 3.112202841922463], "isController": false}, {"data": ["Finance initiates payment", 50, 0, 0.0, 280.87999999999994, 97, 684, 236.5, 488.4, 596.0999999999998, 684.0, 4.646840148698885, 4.873736640334573, 3.108481935408922], "isController": false}, {"data": ["Lead assigns assessor", 50, 0, 0.0, 299.64, 96, 778, 263.0, 573.8, 664.0999999999998, 778.0, 4.845430758794456, 3.487385223858901, 3.042589822172691], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 93509, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
