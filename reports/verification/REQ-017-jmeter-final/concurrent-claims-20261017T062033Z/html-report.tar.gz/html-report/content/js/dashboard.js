/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9990148486579098, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9, 500, 1500, "Lead starts assessment"], "isController": false}, {"data": [1.0, 500, 1500, "Create claim"], "isController": false}, {"data": [0.02, 500, 1500, "Concurrent complete claims workflow"], "isController": true}, {"data": [0.9999330911871535, 500, 1500, "Get session and CSRF token"], "isController": false}, {"data": [0.93, 500, 1500, "Record required invoice"], "isController": false}, {"data": [0.83, 500, 1500, "Assessor records report"], "isController": false}, {"data": [1.0, 500, 1500, "Authenticated list claims"], "isController": false}, {"data": [0.81, 500, 1500, "Clerk verifies documents"], "isController": false}, {"data": [0.8, 500, 1500, "Assessor approves"], "isController": false}, {"data": [0.84, 500, 1500, "Finance initiates payment"], "isController": false}, {"data": [0.87, 500, 1500, "Lead assigns assessor"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 105010, 0, 0.0, 25.817179316255604, 0, 1295, 15.0, 52.0, 63.0, 89.0, 1749.1754672352333, 7218.775457579247, 593.0939264625046], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Lead starts assessment", 50, 0, 0.0, 371.3399999999999, 136, 1124, 316.0, 627.3999999999999, 897.199999999999, 1124.0, 4.58547322083639, 4.674764564609318, 3.0450408107116655], "isController": false}, {"data": ["Create claim", 50, 0, 0.0, 49.95999999999999, 9, 198, 35.5, 119.0, 155.74999999999994, 198.0, 5.31236719082023, 3.594563456226094, 3.263163049830004], "isController": false}, {"data": ["Concurrent complete claims workflow", 50, 0, 0.0, 2863.2599999999998, 1224, 5266, 2715.0, 4274.2, 4471.15, 5266.0, 4.0251167283851235, 25.221680159193365, 18.596510978505876], "isController": true}, {"data": ["Get session and CSRF token", 52310, 0, 0.0, 9.330548652265263, 0, 1020, 4.0, 15.0, 21.0, 35.0, 871.3976345160753, 485.96730280692987, 288.4371616275196], "isController": false}, {"data": ["Record required invoice", 50, 0, 0.0, 351.50000000000006, 126, 985, 320.0, 585.1, 837.5499999999998, 985.0, 5.14668039114771, 3.538041205609882, 3.488082218219249], "isController": false}, {"data": ["Assessor records report", 50, 0, 0.0, 441.4199999999999, 143, 1167, 389.0, 899.1999999999998, 1090.2499999999998, 1167.0, 4.501260352898812, 3.393264567203817, 2.918786010082823], "isController": false}, {"data": ["Authenticated list claims", 52300, 0, 0.0, 39.71931166347994, 3, 394, 35.0, 63.0, 74.0, 104.0, 907.8285019961812, 7010.106108151796, 312.95259883266795], "isController": false}, {"data": ["Clerk verifies documents", 50, 0, 0.0, 414.2600000000001, 122, 1063, 358.5, 856.0999999999998, 960.8999999999995, 1063.0, 4.880905896134323, 4.8657483954021865, 3.269825629636861], "isController": false}, {"data": ["Assessor approves", 50, 0, 0.0, 456.40000000000003, 139, 1085, 403.0, 748.6999999999999, 961.55, 1085.0, 4.492362982929021, 4.671969760781671, 2.9788227201257858], "isController": false}, {"data": ["Finance initiates payment", 50, 0, 0.0, 415.66, 129, 1295, 399.5, 716.5999999999999, 864.6499999999993, 1295.0, 4.442075337597726, 4.658713269589552, 2.9715054748578535], "isController": false}, {"data": ["Lead assigns assessor", 50, 0, 0.0, 412.68, 122, 1137, 311.5, 868.0, 965.5999999999999, 1137.0, 4.692192192192192, 3.3768204239395643, 2.946366776933183], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 105010, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
