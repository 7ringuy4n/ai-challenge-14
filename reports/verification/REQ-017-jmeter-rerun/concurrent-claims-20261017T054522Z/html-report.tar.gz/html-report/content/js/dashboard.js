/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9995494287799574, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.95, 500, 1500, "Lead starts assessment"], "isController": false}, {"data": [1.0, 500, 1500, "Create claim"], "isController": false}, {"data": [0.22, 500, 1500, "Concurrent complete claims workflow"], "isController": true}, {"data": [0.9999701108886033, 500, 1500, "Get session and CSRF token"], "isController": false}, {"data": [0.92, 500, 1500, "Record required invoice"], "isController": false}, {"data": [0.92, 500, 1500, "Assessor records report"], "isController": false}, {"data": [1.0, 500, 1500, "Authenticated list claims"], "isController": false}, {"data": [0.95, 500, 1500, "Clerk verifies documents"], "isController": false}, {"data": [0.97, 500, 1500, "Assessor approves"], "isController": false}, {"data": [0.98, 500, 1500, "Finance initiates payment"], "isController": false}, {"data": [0.92, 500, 1500, "Lead assigns assessor"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 134224, 0, 0.0, 20.23279741327933, 0, 840, 11.0, 49.0, 59.0, 82.0, 2236.9548189257202, 9230.710095354607, 757.9117463397663], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Lead starts assessment", 50, 0, 0.0, 256.54, 88, 747, 195.0, 509.69999999999993, 703.8499999999997, 747.0, 4.612971676353907, 4.702798488098533, 3.0633015038287663], "isController": false}, {"data": ["Create claim", 50, 0, 0.0, 21.52, 3, 125, 14.0, 43.899999999999984, 76.54999999999993, 125.0, 5.231767290990897, 3.540026289630637, 3.213653931673119], "isController": false}, {"data": ["Concurrent complete claims workflow", 50, 0, 0.0, 1809.9799999999996, 655, 3695, 1763.0, 3210.7999999999997, 3460.899999999999, 3695.0, 4.069010416666667, 25.496721267700195, 18.799304962158203], "isController": true}, {"data": ["Get session and CSRF token", 66914, 0, 0.0, 6.054517739187573, 0, 814, 3.0, 8.0, 11.0, 23.0, 1115.3076871791452, 621.9757749474965, 369.18470345939727], "isController": false}, {"data": ["Record required invoice", 50, 0, 0.0, 268.21999999999997, 73, 825, 186.0, 617.9999999999999, 739.9499999999997, 825.0, 4.93875938364283, 3.3951076958218094, 3.3471670041485577], "isController": false}, {"data": ["Assessor records report", 50, 0, 0.0, 272.82, 90, 840, 198.5, 670.2999999999998, 715.3999999999999, 840.0, 4.509786236132407, 3.3996917842969245, 2.9243145124921077], "isController": false}, {"data": ["Authenticated list claims", 66910, 0, 0.0, 33.164265431175934, 3, 377, 31.0, 56.0, 65.0, 91.0, 1139.9802364807306, 8794.887101162385, 392.9814682399393], "isController": false}, {"data": ["Clerk verifies documents", 50, 0, 0.0, 247.59999999999997, 86, 747, 197.5, 500.79999999999995, 601.2999999999996, 747.0, 4.777374355054462, 4.763098216845022, 3.200467585515001], "isController": false}, {"data": ["Assessor approves", 50, 0, 0.0, 263.3, 83, 785, 229.0, 446.8, 594.1499999999997, 785.0, 4.380201489268506, 4.55532399802891, 2.904450010950504], "isController": false}, {"data": ["Finance initiates payment", 50, 0, 0.0, 237.58, 100, 534, 207.5, 437.99999999999994, 504.4999999999998, 534.0, 4.2673039173849965, 4.4749182544593324, 2.85459295254758], "isController": false}, {"data": ["Lead assigns assessor", 50, 0, 0.0, 263.9000000000001, 74, 708, 180.5, 618.8, 664.0999999999998, 708.0, 4.729921483303377, 3.4039729862359285, 2.970058118910226], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 134224, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
